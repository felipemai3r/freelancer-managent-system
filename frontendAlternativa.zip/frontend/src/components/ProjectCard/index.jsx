import React from 'react';
import Button from '../ui/Button';
import styles from './ProjectCard.module.css';

const ProjectCard = ({ projeto }) => {
  const handleView = () => {
    console.log('Ver projeto:', projeto);
    // TODO: Quando o backend estiver pronto, navegar para detalhes
  };

  return (
    <div className={`${styles.card} animate__animated animate__fadeInUp`}>
      <h3 className={styles.title}>{projeto.titulo || 'Sem título'}</h3>
      
      {projeto.empresaNome && (
        <p className={styles.company}>
          <strong>Empresa:</strong> {projeto.empresaNome}
        </p>
      )}

      {projeto.descricao && (
        <p className={styles.description}>{projeto.descricao}</p>
      )}

      {projeto.status && (
        <div className={styles.status}>
          Status: <span className={styles.statusBadge}>{projeto.status}</span>
        </div>
      )}

      <div className={styles.actions}>
        <Button variant="primary" onClick={handleView}>
          Ver
        </Button>
      </div>
    </div>
  );
};

export default ProjectCard;
