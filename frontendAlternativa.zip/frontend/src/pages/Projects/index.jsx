import React, { useState } from 'react';
import ProjectCard from '../../components/ProjectCard';
import styles from './Projects.module.css';

const Projects = () => {
  // Mock data - backend ainda não implementou
  const [projects] = useState([
    {
      id: 1,
      titulo: 'Website Corporativo',
      empresaNome: 'Tech Solutions',
      descricao: 'Desenvolvimento de website institucional moderno',
      status: 'Em andamento',
    },
    {
      id: 2,
      titulo: 'App Mobile',
      empresaNome: 'StartupXYZ',
      descricao: 'Aplicativo mobile para gestão de tarefas',
      status: 'Planejamento',
    },
  ]);

  return (
    <div className={`${styles.page} animate__animated animate__fadeInUp`}>
      <h1 className={styles.title}>Projetos</h1>

      <div className={styles.notice}>
        ⚠️ Os endpoints de projetos ainda estão sendo implementados pelo backend.
        Exibindo dados de exemplo.
      </div>

      {projects.length === 0 ? (
        <p className={styles.empty}>Nenhum projeto cadastrado ainda.</p>
      ) : (
        <div className={styles.grid}>
          {projects.map((projeto) => (
            <ProjectCard key={projeto.id} projeto={projeto} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Projects;
