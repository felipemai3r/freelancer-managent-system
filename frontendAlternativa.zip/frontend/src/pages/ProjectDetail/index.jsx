import React from 'react';
import styles from './ProjectDetail.module.css';

const ProjectDetail = () => {
  return (
    <div className={`${styles.page} animate__animated animate__fadeInUp`}>
      <h1 className={styles.title}>Detalhes do Projeto</h1>

      <div className={styles.card}>
        <p className={styles.message}>
          ⚠️ O backend ainda não implementou os endpoints de projeto individual.
          Esta página será desenvolvida quando os endpoints estiverem disponíveis.
        </p>
      </div>
    </div>
  );
};

export default ProjectDetail;
