import axiosClient from './axiosClient';

const freelancerService = {
  listar: () => axiosClient.get('/api/freelancers'),
  buscarPorId: (id) => axiosClient.get(`/api/freelancers/${id}`),
  listarAtivos: () => axiosClient.get('/api/freelancers/ativos'),
  buscarPorEspecialidade: (especialidade) => axiosClient.get(`/api/freelancers/especialidade/${especialidade}`),
  criar: (freelancer) => axiosClient.post('/api/freelancers', freelancer),
  editar: (id, data) => axiosClient.put(`/api/freelancers/${id}`, data),
  desativar: (id) => axiosClient.put(`/api/freelancers/${id}/desativar`),
  ativar: (id) => axiosClient.put(`/api/freelancers/${id}/ativar`),
  listarTarefas: (freelancerId) => axiosClient.get(`/api/freelancers/${freelancerId}/tarefas`),
};

export default freelancerService;
