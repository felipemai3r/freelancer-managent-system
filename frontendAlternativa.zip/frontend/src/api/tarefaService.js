import axiosClient from './axiosClient';

const tarefaService = {
  listar: async () => {
    const response = await axiosClient.get('/api/tarefas');
    return response;
  },

  buscarPorId: async (projetoId, atividadeId, tarefaId) => {
    const response = await axiosClient.get(`/api/tarefas/${projetoId}/${atividadeId}/${tarefaId}`);
    return response;
  },

  listarPorAtividade: async (projetoId, atividadeId) => {
    const response = await axiosClient.get(`/api/atividades/${projetoId}/${atividadeId}/tarefas`);
    return response;
  },

  listarPorFreelancer: async (freelancerId) => {
    const response = await axiosClient.get(`/api/freelancers/${freelancerId}/tarefas`);
    return response;
  },

  listarAtrasadas: async () => {
    const response = await axiosClient.get('/api/tarefas/atrasadas');
    return response;
  },

  listarPorStatus: async (status) => {
    const response = await axiosClient.get(`/api/tarefas/status/${status}`);
    return response;
  },

  criar: async (payload) => {
    const response = await axiosClient.post('/api/tarefas', payload);
    return response;
  },

  editar: async (projetoId, atividadeId, tarefaId, payload) => {
    const response = await axiosClient.put(`/api/tarefas/${projetoId}/${atividadeId}/${tarefaId}`, payload);
    return response;
  },

  atualizarStatus: async (projetoId, atividadeId, tarefaId, status, dataConclusao = null) => {
    const response = await axiosClient.put(`/api/tarefas/${projetoId}/${atividadeId}/${tarefaId}/status`, {
      status,
      dataConclusao,
    });
    return response;
  },

  remover: async (projetoId, atividadeId, tarefaId) => {
    const response = await axiosClient.delete(`/api/tarefas/${projetoId}/${atividadeId}/${tarefaId}`);
    return response;
  },
};

export default tarefaService;
