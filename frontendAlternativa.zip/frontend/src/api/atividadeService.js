import axiosClient from './axiosClient';

const atividadeService = {
  listar: async () => {
    const response = await axiosClient.get('/api/atividades');
    return response;
  },

  buscarPorId: async (projetoId, atividadeId) => {
    const response = await axiosClient.get(`/api/atividades/${projetoId}/${atividadeId}`);
    return response;
  },

  listarPorProjeto: async (projetoId) => {
    const response = await axiosClient.get(`/api/projetos/${projetoId}/atividades`);
    return response;
  },

  criar: async (payload) => {
    const response = await axiosClient.post('/api/atividades', payload);
    return response;
  },

  editar: async (projetoId, atividadeId, payload) => {
    const response = await axiosClient.put(`/api/atividades/${projetoId}/${atividadeId}`, payload);
    return response;
  },

  atualizarOrdem: async (projetoId, atividadeId, ordem) => {
    const response = await axiosClient.put(`/api/atividades/${projetoId}/${atividadeId}/ordem`, { ordem });
    return response;
  },

  remover: async (projetoId, atividadeId) => {
    const response = await axiosClient.delete(`/api/atividades/${projetoId}/${atividadeId}`);
    return response;
  },
};

export default atividadeService;
