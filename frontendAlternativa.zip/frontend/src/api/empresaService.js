import axiosClient from './axiosClient';

const empresaService = {
  listar: () => axiosClient.get('/api/empresas'),
  buscarPorId: (id) => axiosClient.get(`/api/empresas/${id}`),
  listarAtivas: () => axiosClient.get('/api/empresas/ativas'),
  criar: (empresa) => axiosClient.post('/api/empresas', empresa),
  editar: (id, data) => axiosClient.put(`/api/empresas/${id}`, data),
  desativar: (id) => axiosClient.put(`/api/empresas/${id}/desativar`),
  ativar: (id) => axiosClient.put(`/api/empresas/${id}/ativar`),
  listarProjetos: (empresaId) => axiosClient.get(`/api/empresas/${empresaId}/projetos`),
};

export default empresaService;
