// frontend/src/tarefaService.js
import axiosClient from './axiosClient';

const tarefaService = {
  // ✅ CORRETO: listar tarefas de uma atividade
  listarPorAtividade: async (atividadeId) => {
    const response = await axiosClient.get(`/atividades/${atividadeId}/tarefas`);
    return response;
  },

  // ✅ CORRETO: buscar tarefa específica
  buscarPorId: async (atividadeId, tarefaId) => {
    const response = await axiosClient.get(`/atividades/${atividadeId}/tarefas/${tarefaId}`);
    return response;
  },

  // ✅ CORRETO: criar tarefa dentro de uma atividade
  criar: async (atividadeId, payload) => {
    const response = await axiosClient.post(`/atividades/${atividadeId}/tarefas`, payload);
    return response;
  },

  // ✅ CORRETO: editar tarefa (incluindo status)
  editar: async (atividadeId, tarefaId, payload) => {
    const response = await axiosClient.put(`/atividades/${atividadeId}/tarefas/${tarefaId}`, payload);
    return response;
  },

  // ✅ CORRETO: atualizar status (usa o editar com payload parcial)
  atualizarStatus: async (atividadeId, tarefaId, status) => {
    const response = await axiosClient.put(`/atividades/${atividadeId}/tarefas/${tarefaId}`, {
      status,
    });
    return response;
  },

  // ✅ CORRETO: remover tarefa
  remover: async (atividadeId, tarefaId) => {
    const response = await axiosClient.delete(`/atividades/${atividadeId}/tarefas/${tarefaId}`);
    return response;
  },
};

export default tarefaService;